import React from "react";
import StaffHeader from "./StaffHeader";

export default function StaffDashboard(){
    return(
        <StaffHeader />
    )
}